import React, { useEffect, useRef, useState } from 'react';
import bwipjs from 'bwip-js';
import { BrowserMultiFormatReader } from '@zxing/browser';
import * as XLSX from 'xlsx';
import {
  Barcode, Camera, CameraOff, CheckCircle2, CircleAlert, Download,
  Eraser, Hash, Plus, ScanLine, Search, Trash2, X
} from 'lucide-react';

export default function App() {
  const [barcodeText, setBarcodeText] = useState('');
  const [scanInput, setScanInput] = useState('');
  const [items, setItems] = useState([]);
  const [message, setMessage] = useState(null);
  const [search, setSearch] = useState('');
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const barcodeCanvas = useRef(null);
  const videoRef = useRef(null);
  const readerRef = useRef(null);
  const controlsRef = useRef(null);
  const lastScanRef = useRef({ value: '', time: 0 });

  useEffect(() => {
    if (!barcodeText.trim() || !barcodeCanvas.current) return;
    try {
      bwipjs.toCanvas(barcodeCanvas.current, {
        bcid: 'code128', text: barcodeText.trim(), scale: 3,
        height: 16, includetext: true, textxalign: 'center',
        padding: 12, backgroundcolor: 'FFFFFF'
      });
    } catch {
      const ctx = barcodeCanvas.current.getContext('2d');
      ctx.clearRect(0, 0, barcodeCanvas.current.width, barcodeCanvas.current.height);
    }
  }, [barcodeText]);

  useEffect(() => () => stopCamera(), []);

  const notify = (type, text) => {
    setMessage({ type, text });
    window.clearTimeout(notify.timer);
    notify.timer = window.setTimeout(() => setMessage(null), 3200);
  };

  const addCode = (raw) => {
    const value = String(raw ?? '').trim();
    if (!value) return;
    if (items.some(item => item.code.toLowerCase() === value.toLowerCase())) {
      notify('warning', `Mã "${value}" đã tồn tại trong danh sách.`);
      return;
    }
    setItems(prev => [...prev, {
      id: `${Date.now()}-${Math.random()}`,
      code: value,
      scannedAt: new Date()
    }]);
    setScanInput('');
    notify('success', `Đã thêm mã ${value} vào danh sách.`);
  };

  const handleScanSubmit = (e) => {
    e.preventDefault();
    addCode(scanInput);
  };

  const startCamera = async () => {
    setCameraError('');
    try {
      const reader = new BrowserMultiFormatReader();
      readerRef.current = reader;
      setCameraOn(true);
      await new Promise(resolve => setTimeout(resolve, 100));
      controlsRef.current = await reader.decodeFromVideoDevice(
        undefined, videoRef.current,
        (result) => {
          if (result) {
            const value = result.getText();
            const now = Date.now();
            if (lastScanRef.current.value !== value || now - lastScanRef.current.time > 1800) {
              lastScanRef.current = { value, time: now };
              addCode(value);
            }
          }
        }
      );
    } catch (err) {
      setCameraError(err?.message || 'Không thể mở camera. Hãy kiểm tra quyền truy cập camera.');
      setCameraOn(false);
    }
  };

  const stopCamera = () => {
    try { controlsRef.current?.stop(); } catch {}
    controlsRef.current = null;
    setCameraOn(false);
  };

  const removeItem = (id) => {
    setItems(prev => prev.filter(item => item.id !== id));
    notify('success', 'Đã xóa mã khỏi danh sách.');
  };

  const exportExcel = () => {
    if (!items.length) return notify('warning', 'Danh sách đang trống, chưa thể xuất Excel.');
    const rows = items.map((item, index) => ({
      'STT': index + 1,
      'Mã Code 128': item.code,
      'Thời gian quét': item.scannedAt.toLocaleString('vi-VN')
    }));
    const sheet = XLSX.utils.json_to_sheet(rows);
    sheet['!cols'] = [{ wch: 8 }, { wch: 32 }, { wch: 24 }];
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, 'Danh sach ma vach');
    XLSX.writeFile(book, `Danh_sach_Code128_${new Date().toISOString().slice(0,10)}.xlsx`);
    notify('success', 'Đã xuất file Excel thành công.');
  };

  const filteredItems = items.filter(item =>
    item.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <a className="brand" href="#">
            <span className="brand-icon"><Barcode size={25} /></span>
            <span>Code<span className="brand-accent">128</span> Manager</span>
          </a>
          <div className="topbar-tag"><span className="status-dot" /> HỆ THỐNG QUẢN LÝ MÃ VẠCH</div>
        </div>
      </header>

      <main className="main-content">
        <section className="welcome">
          <div>
            <div className="eyebrow">CÔNG CỤ QUẢN LÝ & KIỂM KÊ</div>
            <h1>Quản lý mã vạch <span>Code 128</span></h1>
            <p>Tạo mã, quét barcode và quản lý danh sách tập trung một cách nhanh chóng.</p>
          </div>
          <div className="welcome-mark"><Barcode size={64} strokeWidth={1.2} /></div>
        </section>

        <section className="workspace">
          <div className="panel generator-panel">
            <div className="panel-heading">
              <div className="heading-icon purple"><Barcode size={20}/></div>
              <div><h2>Tạo mã Code 128</h2><p>Nhập nội dung để tạo mã vạch</p></div>
            </div>
            <label htmlFor="barcodeText">Nội dung mã</label>
            <div className="input-with-button">
              <input id="barcodeText" value={barcodeText} onChange={e => setBarcodeText(e.target.value)}
                placeholder="Ví dụ: SP001234567" maxLength={80}
                onKeyDown={e => e.key === 'Enter' && addCode(barcodeText)} />
              <button className="primary-button compact" onClick={() => addCode(barcodeText)} disabled={!barcodeText.trim()}>
                <Plus size={17}/> Thêm vào DS
              </button>
            </div>
            <div className="barcode-preview">
              {barcodeText.trim() ? <canvas ref={barcodeCanvas} aria-label="Mã vạch Code 128 được tạo" /> :
                <div className="empty-preview"><Barcode size={35}/><span>Mã vạch sẽ hiển thị tại đây</span></div>}
            </div>
            <div className="preview-caption"><span><CheckCircle2 size={14}/> Chuẩn Code 128</span><span>Hỗ trợ chữ và số</span></div>
          </div>

          <div className="panel scanner-panel">
            <div className="panel-heading">
              <div className="heading-icon blue"><ScanLine size={20}/></div>
              <div><h2>Quét mã vạch</h2><p>Dùng camera hoặc máy quét USB</p></div>
            </div>
            <form onSubmit={handleScanSubmit}>
              <label htmlFor="scanInput">Nhập mã / Máy quét USB</label>
              <div className="input-with-button">
                <input id="scanInput" autoComplete="off" value={scanInput}
                  onChange={e => setScanInput(e.target.value)}
                  placeholder="Đưa con trỏ vào đây và quét mã..." />
                <button className="primary-button compact" type="submit" disabled={!scanInput.trim()}>
                  <Plus size={17}/> Ghi nhận
                </button>
              </div>
            </form>
            <div className="camera-box">
              {cameraOn ? <video ref={videoRef} className="camera-video" muted playsInline /> :
                <div className="camera-placeholder"><Camera size={34}/><strong>Quét bằng camera</strong><span>Cho phép trình duyệt truy cập camera để bắt đầu</span></div>}
            </div>
            {cameraError && <p className="error-text">{cameraError}</p>}
            <button className={cameraOn ? 'secondary-button stop-button' : 'secondary-button'} onClick={cameraOn ? stopCamera : startCamera}>
              {cameraOn ? <><CameraOff size={17}/> Tắt camera</> : <><Camera size={17}/> Bật camera quét mã</>}
            </button>
            <p className="helper-text">Máy quét barcode USB thường hoạt động như bàn phím: quét mã vào ô nhập liệu rồi nhấn Enter.</p>
          </div>
        </section>

        <section className="panel list-panel">
          <div className="list-heading">
            <div className="panel-heading">
              <div className="heading-icon green"><Hash size={20}/></div>
              <div><h2>Danh sách mã đã quét</h2><p>Kiểm tra, tìm kiếm và quản lý các mã đã ghi nhận</p></div>
            </div>
            <div className="list-actions">
              <button className="export-button" onClick={exportExcel}><Download size={17}/> Xuất Excel</button>
              <button className="clear-button" onClick={() => {
                if (items.length && window.confirm('Bạn có chắc muốn xóa toàn bộ danh sách?')) {
                  setItems([]); notify('success', 'Đã xóa toàn bộ danh sách.');
                }
              }} disabled={!items.length}><Eraser size={16}/> Xóa tất cả</button>
            </div>
          </div>

          <div className="stats-row">
            <div className="stat-card"><span>TỔNG SỐ MÃ</span><strong>{items.length}</strong><Barcode size={23}/></div>
            <div className="stat-card"><span>MÃ DUY NHẤT</span><strong>{new Set(items.map(x => x.code.toLowerCase())).size}</strong><CheckCircle2 size={23}/></div>
            <div className="stat-card"><span>TRẠNG THÁI</span><strong className="ready-text">{items.length ? 'Đang hoạt động' : 'Chưa có dữ liệu'}</strong><span className="status-dot"/></div>
          </div>

          <div className="table-toolbar">
            <div className="table-title">Dữ liệu đã ghi nhận <span>{items.length}</span></div>
            <div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Tìm mã vạch..."/></div>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th className="stt-col">STT</th><th>NỘI DUNG MÃ CODE 128</th><th>THỜI GIAN QUÉT</th><th className="action-col">THAO TÁC</th></tr></thead>
              <tbody>
                {filteredItems.length ? filteredItems.map((item) => (
                  <tr key={item.id}>
                    <td className="stt-cell">{items.findIndex(x => x.id === item.id) + 1}</td>
                    <td><div className="code-cell"><span className="mini-barcode"><Barcode size={17}/></span><strong>{item.code}</strong></div></td>
                    <td className="time-cell">{item.scannedAt.toLocaleString('vi-VN')}</td>
                    <td><button className="delete-button" title="Xóa mã" onClick={() => removeItem(item.id)}><Trash2 size={16}/></button></td>
                  </tr>
                )) : <tr><td colSpan="4"><div className="table-empty"><Barcode size={32}/><strong>{items.length ? 'Không tìm thấy mã phù hợp' : 'Chưa có mã vạch nào'}</strong><span>{items.length ? 'Thử tìm kiếm với nội dung khác.' : 'Quét mã hoặc nhập mã để bắt đầu danh sách.'}</span></div></td></tr>}
              </tbody>
            </table>
          </div>
          <div className="table-footer"><span>Hiển thị {filteredItems.length} / {items.length} mã</span><span><span className="status-dot"/> Dữ liệu lưu trong phiên làm việc hiện tại</span></div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-inner"><div className="footer-brand"><Barcode size={19}/> Code128 Manager</div><span>© {new Date().getFullYear()} Code128 Manager. Công cụ tạo và quản lý mã vạch.</span><span className="footer-version">VERSION 1.0</span></div>
      </footer>

      {message && <div className={`toast ${message.type}`}><span>{message.type === 'success' ? <CheckCircle2 size={19}/> : <CircleAlert size={19}/>}</span>{message.text}<button onClick={() => setMessage(null)}><X size={16}/></button></div>}
    </div>
  );
}